BAS EDUCATION — Notification setup (GitHub Pages)

WHAT IS INCLUDED
- index.html: updated website with a notification subscribe section
- karnataka-history.html: Karnataka history article
- OneSignalSDKWorker.js: required OneSignal service worker

IMPORTANT: Notifications are NOT active until the owner completes the OneSignal setup below. Do not publish API secrets in website code.

A) OneSignal web push (reader subscription + owner-triggered sends)
1. Create/sign in to a OneSignal account: https://onesignal.com/
2. Create an app and choose Web Push / Custom Code setup. Enter the exact GitHub Pages site URL: https://baseducation003.github.io/Bas-education/
3. Copy the OneSignal App ID (public app ID, not REST API key).
4. In index.html, replace YOUR_ONESIGNAL_APP_ID with that App ID.
5. Upload index.html and OneSignalSDKWorker.js to the ROOT of the GitHub repository (same level as index.html). Commit changes.
6. Wait for GitHub Pages deployment. Open the site in Chrome and press “ಅಧಿಸೂಚನೆ ಪಡೆಯಿರಿ”; allow notifications. Readers must opt in themselves.
7. To send a new article alert manually: open OneSignal dashboard → Messages / Push → New Push, enter Kannada title/message and article URL, choose subscribed audience, then send. Do this only after the article is live.

B) WhatsApp Channel (manual owner-triggered post)
1. Create a BAS EDUCATION WhatsApp Channel in WhatsApp.
2. Copy its public invite/link.
3. In index.html replace YOUR_WHATSAPP_CHANNEL_URL with the real channel URL. Upload and commit.
4. When a new article is published, share its title, short intro and URL as a post in the Channel. WhatsApp Channel posting is manual; this static GitHub Pages website cannot securely publish to a Channel by itself.

SECURITY
- Never put OneSignal REST API key, private keys, passwords, or WhatsApp credentials in index.html or GitHub.
- Only the public OneSignal App ID belongs in the page.
- The owner presses Send in OneSignal dashboard for each notification.

OneSignal Web SDK documentation: https://documentation.onesignal.com/docs/web-push-quickstart
